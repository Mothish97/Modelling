import rospy
from std_msgs.msg       import Float64

if __name__=='__main__':
    rospy.init_node('assembly_publisher_node')
    pub_joint_fr_right= rospy.Publisher("/joint_fr_right_controller/command",Float64,queue_size=10)
    pub_joint_fr_left= rospy.Publisher("/joint_fr_left_controller/command",Float64,queue_size=10)
    pub_joint_rr_right= rospy.Publisher("/joint_rr_right_controller/command",Float64,queue_size=10)
    pub_joint_rr_left= rospy.Publisher("/joint_rr_left_controller/command",Float64,queue_size=10)
    pub_joint_5= rospy.Publisher("/joint_5_controller/command",Float64,queue_size=10)
    pub_joint_4= rospy.Publisher("/joint_4_controller/command",Float64,queue_size=10)
    pub_joint_3= rospy.Publisher("/joint_3_controller/command",Float64,queue_size=10)
    pub_joint_2= rospy.Publisher("/joint_2_controller/command",Float64,queue_size=10)
    pub_joint_1= rospy.Publisher("/joint_1_controller/command",Float64,queue_size=10)
    
    rate= rospy.Rate(1)
    x=0.5
    j4=-6
    i=0
    while not rospy.is_shutdown():
        try:
            i=i+1
            if(i>1):
                rospy.loginfo("reached") 
                j4=0
            else:
                j4=-6    
            rospy.loginfo("right wheel front") 
            pub_joint_fr_right.publish(-15.0)
            rospy.loginfo("left wheel front") 
            pub_joint_fr_left.publish(0.0)
            rospy.loginfo("right wheel back") 
            pub_joint_rr_right.publish(0.0)
            rospy.loginfo("left wheel back") 
            pub_joint_rr_left.publish(-15.0)
            rospy.loginfo("Joint 5 60 ") 
            pub_joint_5.publish(0) 
            rospy.loginfo("Joint 4 ") 
            pub_joint_4.publish(j4) 
            rospy.loginfo("Joint 3 ") 
            pub_joint_3.publish(x) 
            rospy.loginfo("Joint 2 ") 
            pub_joint_2.publish(0) 
            rospy.loginfo("Joint 1 ") 
            pub_joint_1.publish(x)             
            
            if(x==0.5):
                x=-0.5
            else:
                x=0.5
  

            rate.sleep()
        except rospy.ROSInterruptException:
	        rospy.loginfo("ROS Interrupt Exception! Just ignore the exception!")
        except rospy.ROSTimeMovedBackwardsException:
	        rospy.loginfo("ROS Time Backwards! Just ignore the exception!") 
    
    rospy.loginfo("Published")


