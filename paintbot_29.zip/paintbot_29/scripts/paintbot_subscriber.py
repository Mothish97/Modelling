import rospy
from std_msgs.msg       import Float64

def callback_wheel_l(msgl):
    rospy.loginfo("Left Wheel reciever joint_rr_right_controller -8")
    pub_l= rospy.Publisher("/joint_2_controller/command",Float64,queue_size=10)
    rate= rospy.Rate(2)

    while not rospy.is_shutdown():
        try: 
            pub_l.publish(-8)
            rate.sleep()
        except rospy.ROSInterruptException:
	        rospy.loginfo("ROS Interrupt Exception! Just ignore the exception!")
        except rospy.ROSTimeMovedBackwardsException:
	        rospy.loginfo("ROS Time Byackwards! Just ignore the exception!") 

def callback_wheel_r(msgr):
    rospy.loginfo("Right Wheel reciever joint_rr_left_controller -8")
    pub_r= rospy.Publisher("/joint_5_controller/command",Float64,queue_size=10)
    rate= rospy.Rate(2)

    while not rospy.is_shutdown():
        try: 
            pub_r.publish(8)
            rate.sleep()
        except rospy.ROSInterruptException:
	        rospy.loginfo("ROS Interrupt Exception! Just ignore the exception!")
        except rospy.ROSTimeMovedBackwardsException:
	        rospy.loginfo("ROS Time Backwards! Just ignore the exception!") 


if __name__=='__main__':
    rospy.init_node('assembly_subscriber_node')

    sub_l= rospy.Subscriber("/assembly_left",Float64,callback_wheel_l)

    sub_r= rospy.Subscriber("/assembly_right",Float64,callback_wheel_r)
    rospy.spin()